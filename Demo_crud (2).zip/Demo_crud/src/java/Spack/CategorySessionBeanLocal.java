/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/SessionLocal.java to edit this template
 */
package Spack;

import Entity.Category;
import Entity.Subcategory;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Harsh
 */
@Local
public interface CategorySessionBeanLocal {

    public List<Category> ShowCategorys();

    public String DeleteCategory(int cid);

    //public String AddCategory(Category c);

    public String AddCategory(Category c);

    

    public String UpdateCategory(Category c1);

    public Category SearchCategory(int cid);

    public Subcategory SearchByCategoryByNamedQuery(int id);
    
}
