package Spack;

import Entity.Category;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import static java.lang.System.out;
import java.util.Arrays;

/**
 *
 * @author Harsh
 */
@Named(value = "testPageBean")
@SessionScoped
public class TestPageBean implements Serializable {
    
    //To do addition or sub 
    int n1,n2,ans;
    //To get and set user as String 
    String user;
    //Radio button working with static and dynamic both datas
    String favcolor1,favcolor3;
    //Checkbox 
    String []favNumber1;
    String []favNumber2;
    
    
    //Checkbox workiing starts here 
    public String[] getFavNumber1() {
        return favNumber1;
    }

    public void setFavNumber1(String[] favNumber1) {
        this.favNumber1 = favNumber1;
    }

    public String[] getFavNumber2() {
        return favNumber2;
    }

    public void setFavNumber2(String[] favNumber2) {
        this.favNumber2 = favNumber2;
    }
    
    public String getFavNumber1InString()
    {
        return Arrays.toString(favNumber1);
    }
    
    public String[] getFavNumber2Value()
    {
        favNumber2 = new String[5];
        favNumber2[0] = "Surat - 1";
        favNumber2[1] = "Vapi - 2";
        favNumber2[2] = "Pune - 3";
        favNumber2[3] = "Valsad - 4";
        favNumber2[4] = "Baroda - 5";
       
        return favNumber2;
    }

    public String getFavNumberIn2String()
    {
        return Arrays.toString(favNumber2);
    }
    
    //Radiobutton working starts here
    public  String getFavcolor1() {
        return favcolor1;
    }

    public void setFavcolor1(String favcolor1) {
        this.favcolor1 = favcolor1;
    }

    public String getFavcolor3() {
        return favcolor3;
    }

    public void setFavcolor3(String favcolor3) {
        this.favcolor3 = favcolor3;
    }
    
    //Static daata
    public static class Color
    {
        public String colorLabel;
        public String colorValue;

        public Color(String colorLabel, String colorValue) {
            this.colorLabel = colorLabel; 
            this.colorValue = colorValue;
        }

        public String getColorLabel() {
            return colorLabel;
        }

        public String getColorValue() {
            return colorValue;
        }
    }
    
    //Dynamic data
    Color[] color3List;
    
    public Color[] getFavColor3Value()
    {
        color3List = new Color[4];
        color3List[0] = new Color("Color3 - Red","Red");
        color3List[1] = new Color("Color3 - Green","Green");
        color3List[2] = new Color("Color3 - Blue","Blue");        
        color3List[3] = new Color("Color3 - Black","Black");        
        
        return color3List;
    }
    
    //Radiobutton working ends here

    //Addition starts here 
    public int getN1() {
        return n1;
    }

    public void setN1(int n1) {
        this.n1 = n1;
    }

    public int getN2() {
        return n2;
    }

    public void setN2(int n2) {
        this.n2 = n2;
    }

    public int getAns() {
        return ans;
    }

    public void setAns(int ans) {
        this.ans = ans;
    }
    //Ends here
    
    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
    
    public TestPageBean() {
        
    }
    
    public void onclick()
    {
        System.out.println("Hello" +user);
    }
    
    public void onclick2()
    {
        ans=n1+n2;
    }
    
}
