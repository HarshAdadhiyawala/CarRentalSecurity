/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package Spack;

import Entity.Category;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import testrestclient.TestRestClient;

/**
 *
 * @author Harsh
 */


@Named(value = "categoryCDIBean")
@SessionScoped
public class CategoryCDIBean implements Serializable {

    Integer cid;
    String cname;

    public Integer getCid() {
        return cid;
    }
    
    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }
    
    TestRestClient tr = new TestRestClient();
    
    public String addCategory()
    {
        Category ct= new Category();
        ct.setCategoryname(cname);
        
        String successmsg = tr.AddCategory(cname);
        if(successmsg!="")
        {
            return "inserted";
        }
        return "code inserted";
    }
    
    public List<Category> showCategorys()
    {
            Response rs=tr.ShowCategorys(Response.class);
            ArrayList<Category> slist = new ArrayList<Category>();
            
            GenericType<Collection<Category>> gcstate = new GenericType<Collection<Category>>(){};
            slist = ( ArrayList<Category> ) rs.readEntity(gcstate);
            return slist;
    }
    
    public String deleteCategory(int cid)
    {
        tr.DeleteCategory(cid+"");
        return "CategoryShow.xhtml?faces-redirect=true";
    }
    
    public String searchCategory(int catid)
    {
        Response rs=tr.SearchCategory(Response.class,catid+ "");
        GenericType<Category> gstate=new GenericType<Category>(){};
        Category cc=rs.readEntity(gstate);
        cid=cc.getCategoryid();
        cname=cc.getCategoryname();
        return "CategoryEdit.xhtml?faces-redirect=true";
    }
    
    public String updateCategory()
    {
        Category c = new Category();
        c.setCategoryid(cid);
        c.setCategoryname(cname);
        tr.UpdateCategory(cid+"", cname);
        return "CategoryShow.xhtml?faces-redirect=true";
    }
    
    /**
     * 
     * Creates a new instance of CategoryCDIBean
     */
    public CategoryCDIBean() {
    }
    
}
