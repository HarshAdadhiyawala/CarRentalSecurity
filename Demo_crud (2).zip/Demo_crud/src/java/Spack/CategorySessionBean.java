/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package Spack;

import Entity.Category;
import Entity.Subcategory;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Harsh
 */
@Stateless
public class CategorySessionBean implements CategorySessionBeanLocal {

    @PersistenceContext(unitName = "Demo_crudPU")
    private EntityManager em;

    public void persist(Object object) {
        em.persist(object);
    }

    public List<Category> ShowCategorys()
    {   
        try{
            List<Category> lst=em.createNamedQuery("Category.findAll").getResultList();
            return lst;
        }
        
        catch(Exception ex)
        {
            return null;
        }
            
    }
    
    public String DeleteCategory(int cid)
    {
        try{
            Category c=em.find(Category.class,cid);
            em.remove(c);
            return "Deleted";
        }
        catch(Exception ex)
        {
            return ex.getMessage();
        }
    }
    
    public String AddCategory(Category c)
    {
        try{
            em.persist(c);
            return "Inserted";
        }
        catch(Exception ex)
        {
            return ex.getMessage();
        }
    }
    
    public Category SearchCategory(int cid)
    {
        try{
            Category c=em.find(Category.class, cid);
            return c;
        }
        
        catch(Exception ex)
        {
            return null;
        }       
    }
    
    public String UpdateCategory(Category c1)
    {
        try{
            Category c=em.find(Category.class,c1.getCategoryid());
            c.setCategoryname(c1.getCategoryname());
            em.merge(c);
            return "updated";
            
        }
        catch(Exception ex)
        {
            return ex.getMessage();
        }
    }
    
    public Subcategory SearchByCategoryByNamedQuery(int id)
    {
        try{
            Subcategory sc=(Subcategory)em.createNamedQuery("Subcategory.findBySubcategoryid").setParameter("subcategoryid", id).getSingleResult();
            return sc;
        }
        
        catch(Exception ex)
        {
            return null;
        }
    }       
}
