/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/JerseyClient.java to edit this template
 */
package testrestclient;

import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;

/**
 * Jersey REST client generated for REST resource:GenericResource [generic]<br>
 * USAGE:
 * <pre>
 *        TestRestClient client = new TestRestClient();
 *        Object response = client.XXX(...);
 *        // do whatever with response
 *        client.close();
 * </pre>
 *
 * @author Harsh
 */
public class TestRestClient {

    private WebTarget webTarget;
    private Client client;
    private static final String BASE_URI = "http://localhost:8080/Demo_crud/webresources";

    public TestRestClient() {
        client = javax.ws.rs.client.ClientBuilder.newClient();
        webTarget = client.target(BASE_URI).path("generic");
    }

    public String UpdateCategory(String cid, String Categoryname) throws ClientErrorException {
        return webTarget.path(java.text.MessageFormat.format("UpdateCategory/{0}/{1}", new Object[]{cid, Categoryname})).request().post(null, String.class);
    }

    public <T> T ShowCategorys(Class<T> responseType) throws ClientErrorException {
        WebTarget resource = webTarget;
        resource = resource.path("ShowCategorys");
        return resource.request(javax.ws.rs.core.MediaType.APPLICATION_XML).get(responseType);
    }

    public String DeleteCategory(String cid) throws ClientErrorException {
        return webTarget.path(java.text.MessageFormat.format("DeleteCategory/{0}", new Object[]{cid})).request().delete(String.class);
    }

    public <T> T SearchCategory(Class<T> responseType, String cid) throws ClientErrorException {
        WebTarget resource = webTarget;
        resource = resource.path(java.text.MessageFormat.format("SearchCategory/{0}", new Object[]{cid}));
        return resource.request(javax.ws.rs.core.MediaType.APPLICATION_XML).get(responseType);
    }

    public String AddCategory(String Categoryname) throws ClientErrorException {
 //       return webTarget.path("AddCategory").request().post(null, String.class);
          return webTarget.path(java.text.MessageFormat.format("AddCategory/{0}", new Object[]{ Categoryname})).request().post(null, String.class);
 
    }

    public void putXml(Object requestEntity) throws ClientErrorException {
        webTarget.request(javax.ws.rs.core.MediaType.APPLICATION_XML).put(javax.ws.rs.client.Entity.entity(requestEntity, javax.ws.rs.core.MediaType.APPLICATION_XML));
    }

    public void close() {
        client.close();
    }
    
}
