/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/GenericResource.java to edit this template
 */
package Entity;

import Spack.CategorySessionBeanLocal;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author Harsh
 */
@Path("generic")
public class GenericResource {

    CategorySessionBeanLocal categorySessionBean = lookupCategorySessionBeanLocal();

    @Context
    private UriInfo context;

    public GenericResource() {
    }

    @GET
    @Path("ShowCategorys/")
    @Produces(MediaType.APPLICATION_XML)
    public Collection<Category> ShowCategorys()
    {
        return categorySessionBean.ShowCategorys();    
    }
    
    @POST
    @Path("AddCategory/{Categoryname}")
    //@Produces(MediaType.APPLICATION_XML)
    public String AddCategory(@PathParam("Categoryname") String Categoryname)
    {
        Category c=new Category();
        c.setCategoryname(Categoryname);
        return categorySessionBean.AddCategory(c);    
    }

    @DELETE
    @Path("DeleteCategory/{cid}")
    public String DeleteCategory(@PathParam("cid") int cid)
    {
        return categorySessionBean.DeleteCategory(cid);
    }
    
    
    @GET
    @Path("SearchCategory/{cid}")
    @Produces(MediaType.APPLICATION_XML)
    public Category SearchCategory(@PathParam("cid") int cid)
    {
        return categorySessionBean.SearchCategory(cid);
    }
    
    @POST
    @Path("UpdateCategory/{cid}/{Categoryname}")
    public String UpdateCategory(@PathParam("cid") int cid,@PathParam("Categoryname") String Categoryname)
    {
        Category c=new Category();
        c.setCategoryid(cid);
        c.setCategoryname(Categoryname);
        return categorySessionBean.UpdateCategory(c);
    }
    
    /**
     * PUT method for updating or creating an instance of GenericResource
     * @param content representation for the resource
     */
    
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }

    private CategorySessionBeanLocal lookupCategorySessionBeanLocal() {
        try {
            javax.naming.Context c = new InitialContext();
            return (CategorySessionBeanLocal) c.lookup("java:global/Demo_crud/CategorySessionBean!Spack.CategorySessionBeanLocal");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
}
