/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Harsh
 */
@Entity
@Table(name = "subcategory")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Subcategory.findAll", query = "SELECT s FROM Subcategory s"),
    @NamedQuery(name = "Subcategory.findBySubcategoryid", query = "SELECT s FROM Subcategory s WHERE s.subcategoryid = :subcategoryid"),
    @NamedQuery(name = "Subcategory.findBySubcategoryname", query = "SELECT s FROM Subcategory s WHERE s.subcategoryname = :subcategoryname")})
public class Subcategory implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "subcategoryid")
    private Integer subcategoryid;
    @Basic(optional = false)
    @Column(name = "subcategoryname")
    private String subcategoryname;
    @JoinColumn(name = "categoryid", referencedColumnName = "categoryid")
    @ManyToOne(optional = false)
    private Category categoryid;

    public Subcategory() {
    }

    public Subcategory(Integer subcategoryid) {
        this.subcategoryid = subcategoryid;
    }

    public Subcategory(Integer subcategoryid, String subcategoryname) {
        this.subcategoryid = subcategoryid;
        this.subcategoryname = subcategoryname;
    }

    public Integer getSubcategoryid() {
        return subcategoryid;
    }

    public void setSubcategoryid(Integer subcategoryid) {
        this.subcategoryid = subcategoryid;
    }

    public String getSubcategoryname() {
        return subcategoryname;
    }

    public void setSubcategoryname(String subcategoryname) {
        this.subcategoryname = subcategoryname;
    }

    public Category getCategoryid() {
        return categoryid;
    }

    public void setCategoryid(Category categoryid) {
        this.categoryid = categoryid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (subcategoryid != null ? subcategoryid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Subcategory)) {
            return false;
        }
        Subcategory other = (Subcategory) object;
        if ((this.subcategoryid == null && other.subcategoryid != null) || (this.subcategoryid != null && !this.subcategoryid.equals(other.subcategoryid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entity.Subcategory[ subcategoryid=" + subcategoryid + " ]";
    }
    
}
