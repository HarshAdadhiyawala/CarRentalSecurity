package Servlet;

import Entity.Category;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import testrestclient.TestRestClient;

/**
 *
 * @author Harsh
 */
@WebServlet(name = "TestRestServlet", urlPatterns = {"/TestRestServlet"})
public class TestRestServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
          PrintWriter out = response.getWriter();
           
        try {
            
            TestRestClient tc = new TestRestClient();
            
            //showCategory
            Response rs=tc.ShowCategorys(Response.class);
            ArrayList<Category> slist = new ArrayList<Category>();
            
            GenericType<Collection<Category>> gcstate = new GenericType<Collection<Category>>(){};
            slist = ( ArrayList<Category> ) rs.readEntity(gcstate);
            for (Category  ct : slist)
            {
                out.print(ct.getCategoryid() + "    " + ct.getCategoryname());
            }
            
            //Insert code 
//            Category ct=new Category();
//            ct.setCategoryname("Categoryname");
//            ct.setCategoryname("");
//            String successmsg=ct.AddCategory();
       
            //Delete
//           String msg= tc.DeleteCategory("4");
//           out.print(msg);
       
//           String msg2=tc.AddCategory("Test12");
//           out.print(msg2);
            
            //Search Category
//           Response rs=tc.SearchCategory(Response.class,"12");
//           GenericType<Category> gstate=new GenericType<Category>(){};
//           Category cc=rs.readEntity(gstate);
//           out.print(cc.getCategoryid() + " "+ cc.getCategoryname());
//           
           //Update 
//           Category c=new Category();
//           c.setCategoryid(1);
//           c.setCategoryname("Abc");
//           tc.UpdateCategory("12", "Abc");
//           out.print("Updated..");
        }
        catch(Exception ex)
        {
            out.print(ex.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
